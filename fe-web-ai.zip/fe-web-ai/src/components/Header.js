import React, { useContext, useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Drawer, Badge, Dropdown, Menu, message } from "antd";
import { AuthContext } from "../context/AuthContext";
import { getCart } from "../api/services/cartService";
import { useCart } from "../context/CartContext";
import {
  FiMenu,
  FiUser,
  FiSearch,
  FiMail,
  FiClock,
  FiLogOut,
} from "react-icons/fi";
import { AiOutlineRobot } from "react-icons/ai";
import { ShoppingFilled } from "@ant-design/icons";

const HeaderComponent = () => {
  const { user, logout } = useContext(AuthContext);
  const { cartCount, updateCartCount } = useCart();
  const navigate = useNavigate();
  const [drawerVisible, setDrawerVisible] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
    setDrawerVisible(false);
  };

  const toggleDrawer = () => {
    setDrawerVisible(!drawerVisible);
  };

  const fetchCartCount = async () => {
    try {
      const cartData = await getCart();
      const totalItems = cartData.reduce((sum, item) => sum + item.quantity, 0);
      updateCartCount(totalItems);
    } catch (error) {
      console.error("Error fetching cart count:", error);
      message.error("Failed to fetch cart details.");
    }
  };

  useEffect(() => {
    if (user) {
      fetchCartCount();
    }
  }, [user, fetchCartCount]);

  const profileMenu = (
    <Menu className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg">
      <Menu.Item key="1" onClick={() => navigate("/profile")}>
        <FiUser className="mr-2 text-orange-600" />
        Profile
      </Menu.Item>
      <Menu.Item key="2" onClick={() => navigate("/orders")}>
        <FiClock className="mr-2 text-orange-600" />
        Order History
      </Menu.Item>
      <Menu.Divider />
      <Menu.Item key="3" onClick={handleLogout}>
        <FiLogOut className="mr-2 text-red-500" />
        Logout
      </Menu.Item>
    </Menu>
  );

  return (
    <header className="bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 fixed top-0 w-full z-50 shadow-xl">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo Section */}
          <div
            className="text-3xl font-bold text-white tracking-wide drop-shadow-lg cursor-pointer hover:text-orange-200 transition-all duration-300"
            onClick={() => navigate("/")}
          >
            Clothing Store
          </div>

          {/* Centered Menu */}
          <nav className="hidden md:flex items-center space-x-10">
            <Link
              to="/"
              className="text-white font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            >
              Home
            </Link>
            <Link
              to="/search"
              className="text-white font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            >
              <FiSearch className="mr-2" />
              Search
            </Link>
            <Link
              to="/ai"
              className="text-white font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            >
              <AiOutlineRobot className="mr-2" />
              StyleBot
            </Link>
            <Link
              to="/contact"
              className="text-white font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            >
              <FiMail className="mr-2" />
              Contact
            </Link>
          </nav>

          {/* Right-Side Section */}
          <div className="hidden md:flex items-center space-x-6">
            {/* Cart */}
            <div
              className="cursor-pointer relative"
              onClick={() => navigate("/cart")}
            >
              <Badge count={cartCount} size="small" offset={[8, -8]} color="#f97316">
                <ShoppingFilled className="text-white text-2xl hover:text-orange-200 transition-all duration-300" />
              </Badge>
            </div>

            {/* Profile Dropdown */}
            {user ? (
              <Dropdown overlay={profileMenu} trigger={["click"]}>
                <div className="cursor-pointer flex items-center space-x-2">
                  <FiUser className="text-white text-2xl hover:text-orange-200 transition-all duration-300" />
                  <span className="text-white font-semibold">{user.name}</span>
                </div>
              </Dropdown>
            ) : (
              <Link
                to="/login"
                className="bg-white/90 text-orange-600 font-semibold py-2 px-4 rounded-lg hover:bg-orange-100 transition-all duration-300"
              >
                Login
              </Link>
            )}
          </div>

          {/* Mobile Hamburger Menu */}
          <button className="md:hidden text-white" onClick={toggleDrawer}>
            <FiMenu className="text-3xl hover:text-orange-200 transition-all duration-300" />
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <Drawer
        placement="right"
        onClose={toggleDrawer}
        open={drawerVisible}
        bodyStyle={{ padding: 0 }}
        className="bg-gradient-to-b from-orange-400 via-red-500 to-pink-500"
      >
        <div className="flex flex-col space-y-6 p-6 text-white">
          <Link
            to="/"
            className="text-lg font-semibold hover:text-orange-200 transition-all duration-300"
            onClick={toggleDrawer}
          >
            Home
          </Link>
          <Link
            to="/search"
            className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            onClick={toggleDrawer}
          >
            <FiSearch className="mr-2" />
            Search
          </Link>
          <Link
            to="/ai"
            className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            onClick={toggleDrawer}
          >
            <AiOutlineRobot className="mr-2" />
            StyleBot
          </Link>
          <Link
            to="/contact"
            className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center"
            onClick={toggleDrawer}
          >
            <FiMail className="mr-2" />
            Contact
          </Link>
          <div
            className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center cursor-pointer"
            onClick={() => {
              navigate("/cart");
              toggleDrawer();
            }}
          >
            <ShoppingFilled className="mr-2" />
            Cart ({cartCount})
          </div>
          {user ? (
            <>
              <div
                className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center cursor-pointer"
                onClick={() => {
                  navigate("/profile");
                  toggleDrawer();
                }}
              >
                <FiUser className="mr-2" />
                Profile
              </div>
              <div
                className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center cursor-pointer"
                onClick={() => {
                  navigate("/orders");
                  toggleDrawer();
                }}
              >
                <FiClock className="mr-2" />
                Order History
              </div>
              <div
                className="text-lg font-semibold hover:text-orange-200 transition-all duration-300 flex items-center cursor-pointer"
                onClick={handleLogout}
              >
                <FiLogOut className="mr-2" />
                Logout
              </div>
            </>
          ) : (
            <Link
              to="/login"
              className="text-lg font-semibold hover:text-orange-200 transition-all duration-300"
              onClick={toggleDrawer}
            >
              Login
            </Link>
          )}
        </div>
      </Drawer>
    </header>
  );
};

export default HeaderComponent;