import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  HomeOutlined,
  AppstoreOutlined,
  TagsOutlined,
  ShoppingCartOutlined,
  UserOutlined,
  ReadOutlined,
} from "@ant-design/icons";

const AdminSidebar = ({ isOpen, toggleSidebar }) => {
  const location = useLocation();

  // Menu items array
  const menuItems = [
    { name: "Dashboard", path: "/admin/dashboard", icon: <HomeOutlined /> },
    { name: "Manage Users", path: "/admin/users", icon: <UserOutlined /> },
    {
      name: "Manage Products",
      path: "/admin/products",
      icon: <AppstoreOutlined />,
    },
    {
      name: "Manage Categories",
      path: "/admin/categories",
      icon: <TagsOutlined />,
    },

    {
      name: "Manage Orders",
      path: "/admin/orders",
      icon: <ShoppingCartOutlined />,
    },
  ];

  return (
    <aside
      className={`fixed top-0 left-0 h-full bg-gradient-to-r from-orange-500 to-orange-600 text-white z-50 transform transition-transform duration-300 w-64 ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      } md:translate-x-0`}
    >
      {/* Logo Section */}
      <div className="flex items-center justify-center py-6 bg-orange-700 border-b border-gray-700">
        <h2 className="text-2xl font-bold text-white">HADES</h2>
      </div>

      {/* Navigation Menu */}
      <nav className="mt-6 space-y-4">
        {menuItems.map((item) => (
          <Link
            key={item.name}
            to={item.path}
            className={`flex items-center space-x-4 px-6 py-3 transition-all duration-300 rounded-lg ${
              location.pathname === item.path
                ? "bg-orange-700 text-white"
                : "hover:bg-orange-800 hover:text-white text-gray-300"
            }`}
          >
            {item.icon}
            <span className="font-medium">{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Mobile Close Button */}
      <button
        className="block md:hidden bg-red-600 text-white px-4 py-2 rounded mx-6 mt-6"
        onClick={toggleSidebar}
      >
        Close
      </button>
    </aside>
  );
};

export default AdminSidebar;
