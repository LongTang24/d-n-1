import React, { useState } from "react";
import { Upload, Button, message, Space, Progress } from "antd";
import {
  UploadOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";
import axios from "axios";

const ImageUpload = ({ onImageUpload }) => {
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState(""); // "success" | "error" | ""

  const handleUpload = async ({ file }) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append(
      "upload_preset",
      process.env.REACT_APP_CLOUDINARY_UPLOAD_PRESET
    );

    setLoading(true);
    setUploadStatus("");
    setUploadProgress(0);

    try {
      // Thực hiện upload ảnh và lấy response
      const response = await axios.post(
        `https://api.cloudinary.com/v1_1/${process.env.REACT_APP_CLOUDINARY_CLOUD_NAME}/image/upload`,
        formData,
        {
          onUploadProgress: (progressEvent) => {
            const percent = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setUploadProgress(percent);
          },
        }
      );

      // Nhận URL ảnh sau khi upload thành công
      const imageUrl = response.data.secure_url;
      message.success("Image uploaded successfully");

      if (onImageUpload) {
        onImageUpload(imageUrl); // Pass the URL back to the parent
      }

      setUploadStatus("success");
    } catch (error) {
      message.error("Failed to upload image");
      setUploadStatus("error");
    } finally {
      setLoading(false);
    }
  };

  const renderUploadButton = () => {
    if (loading) {
      return (
        <Space direction="vertical" align="center">
          <Progress type="circle" percent={uploadProgress} status="active" />
          <span className="text-gray-500 mt-2">
            Uploading... {uploadProgress}%
          </span>
        </Space>
      );
    } else if (uploadStatus === "success") {
      return (
        <Space direction="vertical" align="center">
          <CheckCircleOutlined style={{ fontSize: "32px", color: "#4CAF50" }} />
          <span className="text-green-500">Upload Successful!</span>
        </Space>
      );
    } else if (uploadStatus === "error") {
      return (
        <Space direction="vertical" align="center">
          <CloseCircleOutlined style={{ fontSize: "32px", color: "#F44336" }} />
          <span className="text-red-500">Upload Failed</span>
        </Space>
      );
    } else {
      return (
        <Button
          icon={<UploadOutlined />}
          className="bg-orange-500 text-white hover:bg-orange-600"
        >
          {loading ? "Uploading..." : "Upload Image"}
        </Button>
      );
    }
  };

  return (
    <Upload
      customRequest={handleUpload}
      showUploadList={false}
      accept="image/*"
      disabled={loading || uploadStatus === "success"}
    >
      {renderUploadButton()}
    </Upload>
  );
};

export default ImageUpload;
