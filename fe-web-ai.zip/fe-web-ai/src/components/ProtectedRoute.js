import React, { useContext } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const ProtectedRoute = () => {
  const { user, loading } = useContext(AuthContext);

  if (loading) {
    // Hiển thị trong khi đang xác thực
    return (
      <div className="flex justify-center items-center h-screen">
        Loading...
      </div>
    );
  }

  if (!user) {
    // Chuyển hướng nếu chưa đăng nhập
    return <Navigate to="/login" />;
  }

  // Render nội dung được bảo vệ (Outlet cho các route con)
  return <Outlet />;
};

export default ProtectedRoute;
