import React from "react";

const FooterComponent = () => (
  <footer className="bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 text-white py-10 mt-10">
    <div className="max-w-screen-xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
      <div className="text-center md:text-left">
        &copy; {new Date().getFullYear()} Clothing Store. All Rights Reserved.
      </div>
      <div className="space-x-4">
        <a href="#" className="hover:underline">
          Privacy Policy
        </a>
        <a href="#" className="hover:underline">
          Terms of Service
        </a>
      </div>
    </div>
  </footer>
);

export default FooterComponent;
