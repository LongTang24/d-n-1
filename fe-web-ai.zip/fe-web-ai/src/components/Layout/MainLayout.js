import React from "react";
import { Outlet } from "react-router-dom";
import Header from "../Header";
import Footer from "../Footer";

const MainLayout = () => (
  <div className="flex flex-col min-h-screen">
    {/* Header */}
    <header className="fixed top-0 left-0 w-full z-10 bg-white shadow">
      <Header />
    </header>

    {/* Main Content */}
    <main className="flex-grow pt-16 pb-16 bg-gray-50">
      <Outlet />
    </main>

    {/* Footer */}
    <footer className="fixed bottom-0 left-0 w-full z-10 bg-white shadow">
      <Footer />
    </footer>
  </div>
);

export default MainLayout;
