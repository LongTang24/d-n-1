// import axios from "axios";

// const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY; // Store your API key securely
// const GEMINI_API_URL =
//   "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";

// // Function to send a prompt to the Gemini API
// export const sendPromptToGemini = async (prompt) => {
//   if (!prompt.trim()) {
//     throw new Error("Prompt cannot be empty.");
//   }

//   // Predefined context for the AI as a LeonMall e-commerce assistant
//   const leonmallPrompt = `
//  Welcome to Clothing Store, your virtual shopping assistant!

// You are an AI assistant for Clothing Store, a premier online fashion store specializing in high-quality apparel and accessories. Your main task is to guide customers throughout their shopping journey by assisting with product searches, helping with order placements, answering questions, and providing personalized recommendations.

// You are well-versed in Clothing Store' product catalog, current sales, promotions, and customer service policies. Your goal is to make the shopping experience as smooth and enjoyable as possible by offering accurate information and thoughtful responses.

// Always respond in a polite, friendly, and professional manner. Tailor your answers to address customers' needs and help them find exactly what they’re looking for. Whether it’s answering product-related queries, guiding through the checkout process, or assisting with post-purchase support, you're here to make the experience easy and pleasant.

//   `;

//   // Combine the predefined prompt with the user's input
//   const fullPrompt = `${leonmallPrompt} ${prompt}`;

//   try {
//     const response = await axios.post(
//       GEMINI_API_URL,
//       {
//         contents: [
//           {
//             parts: [
//               {
//                 text: fullPrompt, // The full prompt including the predefined context
//               },
//             ],
//           },
//         ],
//       },
//       {
//         params: { key: GEMINI_API_KEY }, // Use the key securely in query parameters
//         headers: {
//           "Content-Type": "application/json", // Ensure correct content type
//         },
//       }
//     );

//     // Extract and return the generated content from the response
//     const resultText = response.data.candidates?.[0]?.content?.parts?.[0]?.text;
//     if (!resultText) {
//       throw new Error("No valid response returned from the AI.");
//     }
//     return resultText;
//   } catch (error) {
//     console.error(
//       "Error communicating with Gemini API:",
//       error.response?.data || error.message
//     );
//     throw new Error(
//       error.response?.data?.error?.message ||
//         "Failed to generate response from Gemini."
//     );
//   }
// };

import axios from "axios";

const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY; // Store your API key securely
const GEMINI_API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";

// Function to send a prompt to the Gemini API
export const sendPromptToGemini = async (prompt) => {
  if (!prompt.trim()) {
    throw new Error("Prompt cannot be empty.");
  }

  // Predefined context for the AI as a LeonMall e-commerce assistant
  const leonmallPrompt = `
Chào mừng đến với Clothing Store, trợ lý mua sắm ảo của bạn!

Bạn là trợ lý AI cho Clothing Store, một cửa hàng thời trang trực tuyến hàng đầu chuyên về trang phục và phụ kiện chất lượng cao. Nhiệm vụ chính của bạn là hướng dẫn khách hàng trong suốt hành trình mua sắm của họ bằng cách hỗ trợ tìm kiếm sản phẩm, hỗ trợ đặt hàng, trả lời các câu hỏi và cung cấp các đề xuất được cá nhân hóa.

Bạn rất am hiểu về danh mục sản phẩm, chương trình khuyến mãi, bán hàng hiện tại và chính sách dịch vụ khách hàng của Clothing Store. Mục tiêu của bạn là làm cho trải nghiệm mua sắm trở nên suôn sẻ và thú vị nhất có thể bằng cách cung cấp thông tin chính xác và phản hồi chu đáo.

Luôn phản hồi một cách lịch sự, thân thiện và chuyên nghiệp. Điều chỉnh câu trả lời của bạn để đáp ứng nhu cầu của khách hàng và giúp họ tìm thấy chính xác những gì họ đang tìm kiếm. Cho dù đó là trả lời các câu hỏi liên quan đến sản phẩm, hướng dẫn trong suốt quá trình thanh toán hay hỗ trợ hỗ trợ sau khi mua hàng, bạn ở đây để làm cho trải nghiệm trở nên dễ dàng và thú vị.

  `;

  // Combine the predefined prompt with the user's input
  const fullPrompt = `${leonmallPrompt} ${prompt}`;

  try {
    const response = await axios.post(
      GEMINI_API_URL,
      {
        contents: [
          {
            parts: [
              {
                text: fullPrompt, // The full prompt including the predefined context
              },
            ],
          },
        ],
      },
      {
        params: { key: GEMINI_API_KEY }, // Use the key securely in query parameters
        headers: {
          "Content-Type": "application/json", // Ensure correct content type
        },
      }
    );

    // Extract and return the generated content from the response
    const resultText = response.data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!resultText) {
      throw new Error("No valid response returned from the AI.");
    }
    return resultText;
  } catch (error) {
    console.error(
      "Error communicating with Gemini API:",
      error.response?.data || error.message
    );
    throw new Error(
      error.response?.data?.error?.message ||
        "Failed to generate response from Gemini."
    );
  }
};
