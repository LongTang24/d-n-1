import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getProducts } from "../api/services/productService";
import { getCategories } from "../api/services/categoryService";
import { addToCart, getCart } from "../api/services/cartService";
import { Button, Badge, Typography, message, Select } from "antd";
import { ShoppingCartOutlined, InfoCircleOutlined } from "@ant-design/icons";
import { useCart } from "../context/CartContext";

const { Title, Paragraph } = Typography;
const { Option } = Select;

const Home = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [priceFilter, setPriceFilter] = useState("all");
  const navigate = useNavigate();
  const { updateCartCount } = useCart();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productsData = await getProducts();
        const categoriesData = await getCategories();
        setProducts(productsData);
        setFilteredProducts(productsData);
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId);
    filterProducts(categoryId, priceFilter);
  };

  const handlePriceFilter = (value) => {
    setPriceFilter(value);
    filterProducts(selectedCategory, value);
  };

  const filterProducts = (categoryId, price) => {
    let filtered = products;
    if (categoryId) {
      filtered = filtered.filter((product) => product.categoryId === categoryId);
    }
    if (price !== "all") {
      const [min, max] = price.split("-").map(Number);
      filtered = filtered.filter(
        (product) => product.price >= min && (max ? product.price <= max : true)
      );
    }
    setFilteredProducts(filtered);
  };

  // Lấy ngẫu nhiên 4 sản phẩm cho Best Sellers
  const bestSellers = [...products]
    .sort(() => Math.random() - 0.5) // Xáo trộn ngẫu nhiên
    .slice(0, 4); // Lấy 4 sản phẩm đầu tiên

  const handleViewDetails = (productId) => {
    navigate(`/product/${productId}`);
  };

  const handleAddToCart = async (product) => {
    try {
      if (product.stock <= 0) {
        message.error("This product is out of stock.");
        return;
      }
      await addToCart(product.id, 1);
      const cartData = await getCart();
      const totalItems = cartData.reduce((sum, item) => sum + item.quantity, 0);
      updateCartCount(totalItems);
      message.success(`${product.name} added to cart successfully!`);
    } catch (error) {
      console.error("Error adding to cart:", error);
      message.error("Failed to add product to cart.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500">
      {/* Hero Section - Bỏ nút Shop Now */}
      <section className="py-20 text-center text-white">
        <div className="container mx-auto px-6">
          <Title level={1} className="font-bold tracking-wide drop-shadow-lg">
            Welcome to Our Clothing Store
          </Title>
          <Paragraph className="text-lg max-w-2xl mx-auto drop-shadow-md">
            Discover the latest trends in fashion with premium quality and unbeatable style.
          </Paragraph>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12">
        <div className="container mx-auto px-6 text-center">
          <Title level={2} className="text-white font-bold tracking-wide drop-shadow-lg mb-8">
            Browse by Category
          </Title>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              onClick={() => handleCategorySelect(null)}
              className={`${
                selectedCategory === null ? "bg-white text-orange-600" : "bg-transparent text-white border-white"
              } border rounded-full px-6 py-2 text-lg font-semibold hover:bg-white hover:text-orange-600 transition-all duration-300`}
            >
              All Categories
            </Button>
            {categories.map((category) => (
              <Button
                key={category.id}
                onClick={() => handleCategorySelect(category.id)}
                className={`${
                  selectedCategory === category.id ? "bg-white text-orange-600" : "bg-transparent text-white border-white"
                } border rounded-full px-6 py-2 text-lg font-semibold hover:bg-white hover:text-orange-600 transition-all duration-300`}
              >
                {category.name}
              </Button>
            ))}
          </div>
          <div className="mt-6">
            <Select
              defaultValue="all"
              onChange={handlePriceFilter}
              className="w-48"
              dropdownClassName="bg-white"
            >
              <Option value="all">All Prices</Option>
              <Option value="0-500000">0 - 500,000 VND</Option>
              <Option value="500000-1000000">500,000 - 1,000,000 VND</Option>
              <Option value="1000000-">1,000,000+ VND</Option>
            </Select>
          </div>
        </div>
      </section>

      {/* Best Sellers Section - Ngẫu nhiên, tăng chiều cao */}
      <section className="py-12 bg-white/10 backdrop-blur-sm">
        <div className="container mx-auto px-6">
          <Title level={2} className="text-white font-bold tracking-wide drop-shadow-lg mb-8 text-center">
            Featured Items
          </Title>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.map((product) => (
              <div
                key={product.id}
                className="relative group bg-white/90 rounded-xl shadow-lg overflow-hidden transform transition-all hover:scale-105"
              >
                <img
                  alt={product.name}
                  src={product.imageUrl || "https://via.placeholder.com/300"}
                  className="w-full h-80 object-cover transition-transform duration-300 group-hover:scale-110" // Tăng chiều cao từ h-64 lên h-80
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center text-white p-4">
                  <Title level={4} className="text-white font-semibold truncate">
                    {product.name}
                  </Title>
                  <p className="text-sm">{product.price.toLocaleString()} VND</p>
                  <div className="flex gap-2 mt-4">
                    <Button
                      icon={<InfoCircleOutlined />}
                      onClick={() => handleViewDetails(product.id)}
                      className="text-white border-white hover:bg-white hover:text-orange-600 rounded-lg"
                    >
                      Details
                    </Button>
                    <Button
                      icon={<ShoppingCartOutlined />}
                      onClick={() => handleAddToCart(product)}
                      className="bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg"
                    >
                      Add
                    </Button>
                  </div>
                </div>
                <Badge
                  count={product.stock > 0 ? "In Stock" : "Out of Stock"}
                  style={{
                    backgroundColor: product.stock > 0 ? "#f97316" : "#e11d48",
                    color: "white",
                    position: "absolute",
                    top: 10,
                    right: 10,
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* All Products Section - Tăng chiều cao */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <Title level={2} className="text-white font-bold tracking-wide drop-shadow-lg mb-8 text-center">
            {selectedCategory
              ? categories.find((cat) => cat.id === selectedCategory)?.name
              : "All Collections"}
          </Title>
          <div className="space-y-8">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="flex flex-col md:flex-row items-center bg-white/90 backdrop-blur-sm rounded-xl shadow-xl overflow-hidden transition-all hover:shadow-2xl"
              >
                <img
                  alt={product.name}
                  src={product.imageUrl || "https://via.placeholder.com/300"}
                  className="w-full md:w-1/3 h-80 object-cover transition-transform duration-300 hover:scale-105" // Tăng chiều cao từ h-64 lên h-80
                />
                <div className="p-6 flex-1">
                  <Title level={4} className="text-orange-600 font-semibold">
                    {product.name}
                  </Title>
                  <Paragraph className="text-gray-600 text-sm line-clamp-2">
                    {product.description}
                  </Paragraph>
                  <div className="flex justify-between items-center mt-4">
                    <span className="text-lg font-bold text-orange-600">
                      {product.price.toLocaleString()} VND
                    </span>
                    <Badge
                      count={product.stock > 0 ? "In Stock" : "Out of Stock"}
                      style={{ backgroundColor: product.stock > 0 ? "#f97316" : "#e11d48", color: "white" }}
                    />
                  </div>
                  <div className="flex gap-4 mt-4">
                    <Button
                      icon={<InfoCircleOutlined />}
                      onClick={() => handleViewDetails(product.id)}
                      className="w-full text-orange-600 border-orange-600 hover:bg-orange-100 rounded-lg transition-all"
                    >
                      View Details
                    </Button>
                    <Button
                      icon={<ShoppingCartOutlined />}
                      onClick={() => handleAddToCart(product)}
                      className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg transition-all"
                    >
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;