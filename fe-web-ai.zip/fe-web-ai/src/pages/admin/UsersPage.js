import React, { useEffect, useState } from "react";
import { Table, Button, Avatar, Popconfirm, message, Spin } from "antd";
import { getAllUsers, deleteUserById } from "../../api/services/userService";

const UsersPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deletingUserId, setDeletingUserId] = useState(null);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await getAllUsers();
      setUsers(data);
    } catch (error) {
      message.error("Failed to fetch users.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      setDeletingUserId(id);
      await deleteUserById(id);
      message.success("User deleted successfully.");
      fetchUsers();
    } catch (error) {
      message.error("Failed to delete user.");
    } finally {
      setDeletingUserId(null);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const columns = [
    {
      title: "Avatar",
      dataIndex: "avatar",
      key: "avatar",
      render: (avatar) => <Avatar src={avatar} size="large" />,
      responsive: ["xs", "sm", "md", "lg"],
    },
    {
      title: "Name",
      dataIndex: "firstName",
      key: "name",
      render: (text, record) => `${record.firstName} ${record.lastName}`,
      ellipsis: true,
      responsive: ["xs", "sm", "md"],
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
      ellipsis: true,
    },
    {
      title: "Phone",
      dataIndex: "phone",
      key: "phone",
      ellipsis: true,
      responsive: ["md", "lg"],
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      render: (role) => (
        <span
          className={`px-2 py-1 rounded-full text-white ${
            role === "admin" ? "bg-blue-500" : "bg-green-500"
          }`}
        >
          {role}
        </span>
      ),
      responsive: ["xs", "sm", "md", "lg"],
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Popconfirm
          title="Are you sure to delete this user?"
          onConfirm={() => handleDelete(record.id)}
          okText="Yes"
          cancelText="No"
        >
          <Button
            danger
            loading={deletingUserId === record.id}
            disabled={deletingUserId === record.id}
            className="text-orange bg-red-600 hover:bg-red-700"
          >
            Delete
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <div className="container mx-auto px-6 py-6">
      <h2 className="text-3xl font-semibold text-gray-800 mb-6">
        Manage Users
      </h2>

      {loading ? (
        <div className="flex justify-center items-center h-60">
          <Spin size="large" />
        </div>
      ) : (
        <Table
          columns={columns}
          dataSource={users}
          rowKey="id"
          bordered
          pagination={{ pageSize: 10 }}
          scroll={{ x: "1000px" }}
          className="shadow-lg rounded-lg"
        />
      )}
    </div>
  );
};

export default UsersPage;
