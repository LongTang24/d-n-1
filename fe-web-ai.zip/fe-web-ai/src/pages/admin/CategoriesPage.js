import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  message,
  Popconfirm,
  Spin,
} from "antd";
import {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
} from "../../api/services/categoryService";

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [form] = Form.useForm();

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    try {
      const data = await getCategories();
      setCategories(data);
    } catch (error) {
      message.error(error.message || "Failed to load categories");
    } finally {
      setLoading(false);
    }
  };

  const handleAddCategory = () => {
    setEditingCategory(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEditCategory = (record) => {
    setEditingCategory(record);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handleDeleteCategory = async (id) => {
    setLoading(true);
    try {
      await deleteCategory(id);
      message.success("Category deleted successfully");
      loadCategories();
    } catch (error) {
      message.error(error.message || "Failed to delete category");
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async (values) => {
    setLoading(true);
    try {
      if (editingCategory) {
        await updateCategory(editingCategory.id, values);
        message.success("Category updated successfully");
      } else {
        await createCategory(values);
        message.success("Category created successfully");
      }
      setModalVisible(false);
      loadCategories();
    } catch (error) {
      message.error(error.message || "Failed to save category");
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      title: "Category Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Created At",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (text) => new Date(text).toLocaleDateString(),
    },
    {
      title: "Actions",
      key: "actions",
      render: (text, record) => (
        <div className="flex space-x-2">
          <Button
            type="link"
            onClick={() => handleEditCategory(record)}
            className="text-orange-600 hover:text-orange-700"
          >
            Edit
          </Button>
          <Popconfirm
            title="Are you sure to delete this category?"
            onConfirm={() => handleDeleteCategory(record.id)}
            okText="Yes"
            cancelText="No"
          >
            <Button type="link" danger>
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  return (
    <div className="p-6 bg-gray-100">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-orange-600">
          Manage Categories
        </h2>
        <Button
          type="primary"
          className="bg-orange-600 hover:bg-orange-700"
          onClick={handleAddCategory}
        >
          Add Category
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center">
          <Spin size="large" />
        </div>
      ) : (
        <Table
          columns={columns}
          dataSource={categories}
          rowKey="id"
          pagination={{ pageSize: 5 }}
          className="bg-white shadow-md rounded-lg"
        />
      )}

      <Modal
        title={editingCategory ? "Edit Category" : "Add Category"}
        visible={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        className="modal-custom"
      >
        <Form form={form} onFinish={handleFormSubmit} layout="vertical">
          <Form.Item
            name="name"
            label="Category Name"
            rules={[
              { required: true, message: "Please enter the category name" },
            ]}
          >
            <Input placeholder="Enter category name" />
          </Form.Item>
          <div className="flex justify-end">
            <Button
              onClick={() => setModalVisible(false)}
              className="border border-gray-300 text-gray-600 hover:bg-gray-200"
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="bg-orange-600 hover:bg-orange-700"
            >
              {editingCategory ? "Update" : "Create"}
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default CategoriesPage;
