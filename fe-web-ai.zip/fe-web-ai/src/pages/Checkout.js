import React, { useState } from "react";
import { Form, Input, Button, message, Typography, Spin } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { placeOrder } from "../api/services/orderService";
import { useCart } from "../context/CartContext";

const { Title, Paragraph } = Typography;

const CheckoutPage = () => {
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const totalAmount = location.state?.total || 0;
  const { resetCart } = useCart();
  const [form] = Form.useForm();

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const orderData = {
        ...values,
        totalAmount: totalAmount,
        orderId: `order_${Date.now()}`,
      };

      const paymentResponse = await placeOrder(orderData);

      if (paymentResponse.payUrl) {
        resetCart(); // Reset giỏ hàng sau khi đặt hàng thành công
        window.location.href = paymentResponse.payUrl;
      } else {
        message.error("Failed to initiate payment");
        navigate("/error");
      }
    } catch (error) {
      message.error(error.message || "Failed to place order. Please try again.");
      navigate("/error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 flex items-center justify-center py-12">
      <div className="bg-white/90 backdrop-blur-sm shadow-xl rounded-xl p-8 w-full max-w-lg">
        {/* Header */}
        <Title level={2} className="text-center text-orange-600 font-bold tracking-wide">
          Checkout
        </Title>
        <Paragraph className="text-center text-gray-700 mb-8">
          Complete your order and get ready to shine with HADES!
        </Paragraph>

        {/* Form */}
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          className="space-y-6"
          requiredMark={false}
        >
          <Form.Item
            name="name"
            label={<span className="text-orange-600 font-semibold">Full Name</span>}
            rules={[{ required: true, message: "Please enter your name" }]}
          >
            <Input
              placeholder="Enter your full name"
              className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
            />
          </Form.Item>

          <Form.Item
            name="phone"
            label={<span className="text-orange-600 font-semibold">Phone Number</span>}
            rules={[
              { required: true, message: "Please enter your phone number" },
              { pattern: /^[0-9]+$/, message: "Please enter a valid number" },
            ]}
          >
            <Input
              placeholder="Enter your phone number"
              className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
            />
          </Form.Item>

          <Form.Item
            name="shippingAddress"
            label={<span className="text-orange-600 font-semibold">Shipping Address</span>}
            rules={[{ required: true, message: "Please enter your shipping address" }]}
          >
            <Input
              placeholder="Enter your shipping address"
              className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
            />
          </Form.Item>

          {/* Total Amount */}
          <div className="flex justify-between items-center mt-6 bg-orange-50/50 p-4 rounded-lg">
            <Title level={4} className="text-orange-600 font-semibold">
              Total:
            </Title>
            <span className="text-xl font-bold text-orange-600">
              {totalAmount.toLocaleString()} VND
            </span>
          </div>

          {/* Submit Button */}
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
            disabled={loading}
            className="w-full mt-4 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold rounded-lg shadow-lg transition-all duration-300 py-2"
          >
            {loading ? <Spin className="text-white" /> : "Place Order"}
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default CheckoutPage;