import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  InputNumber,
  message,
  Spin,
  Typography,
  Divider,
} from "antd";
import { DeleteOutlined, ShoppingCartOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import {
  getCart,
  updateCartQuantity,
  removeFromCart,
} from "../api/services/cartService";
import { useCart } from "../context/CartContext";

const { Title, Text } = Typography;

const CartPage = () => {
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { updateCartCount } = useCart();

  useEffect(() => {
    const fetchCart = async () => {
      setLoading(true);
      try {
        const cartData = await getCart();
        setCart(cartData);
        updateCartCount(cartData.length);
      } catch (error) {
        message.error("Failed to fetch cart items.");
      } finally {
        setLoading(false);
      }
    };

    fetchCart();
  }, [updateCartCount]);

  const handleQuantityChange = async (productId, quantity) => {
    if (quantity < 1) {
      message.error("Quantity must be at least 1.");
      return;
    }

    try {
      await updateCartQuantity(productId, quantity);
      setCart((prevCart) =>
        prevCart.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
      message.success("Quantity updated successfully.");
    } catch (error) {
      message.error("Failed to update quantity.");
    }
  };

  const handleRemoveItem = async (productId) => {
    try {
      await removeFromCart(productId);
      setCart((prevCart) => {
        const updatedCart = prevCart.filter(
          (item) => item.product.id !== productId
        );
        updateCartCount(updatedCart.length);
        return updatedCart;
      });
      message.success("Item removed from cart.");
    } catch (error) {
      message.error("Failed to remove item.");
    }
  };

  const total = cart.reduce(
    (sum, item) => sum + item.quantity * item.product.price,
    0
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const columns = [
    {
      title: "Product",
      dataIndex: "product",
      key: "product",
      render: (product) => (
        <div className="flex items-center space-x-4">
          <img
            src={product.imageUrl || "https://via.placeholder.com/50"}
            alt={product.name}
            className="w-16 h-16 object-cover rounded-md"
          />
          <span className="font-medium">{product.name}</span>
        </div>
      ),
    },
    {
      title: "Price",
      dataIndex: "product",
      key: "price",
      render: (product) => (
        <span className="font-medium text-gray-600">
          {`${product.price.toLocaleString()} VND`}
        </span>
      ),
    },
    {
      title: "Quantity",
      dataIndex: "quantity",
      key: "quantity",
      render: (quantity, record) => (
        <InputNumber
          min={1}
          value={quantity}
          onChange={(value) => handleQuantityChange(record.product.id, value)}
          className="w-16"
        />
      ),
    },
    {
      title: "Subtotal",
      key: "subtotal",
      render: (_, record) => (
        <span className="font-medium text-gray-800">
          {`${(record.quantity * record.product.price).toLocaleString()} VND`}
        </span>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Button
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveItem(record.product.id)}
        />
      ),
    },
  ];

  return (
    <div className="container mx-auto px-6 py-10 bg-gray-50">
      <Title level={2} className="text-center text-orange-600 mb-8">
        Shopping Cart
      </Title>
      <Divider />
      {cart.length > 0 ? (
        <>
          <Table
            dataSource={cart}
            columns={columns}
            rowKey={(record) => record.product.id}
            pagination={false}
            className="rounded-lg overflow-hidden bg-white shadow-md"
          />
          <Divider />
          <div className="flex flex-col sm:flex-row justify-between items-center mt-6 bg-white p-4 rounded-lg shadow-md">
            <Title level={3} className="text-gray-800">
              Total:{" "}
              <span className="text-orange-600">
                {total.toLocaleString()} VND
              </span>
            </Title>
            <Button
              type="primary"
              size="large"
              icon={<ShoppingCartOutlined />}
              className="bg-orange-500 text-white hover:bg-orange-600 mt-4 sm:mt-0"
              onClick={() => navigate("/checkout", { state: { total } })}
            >
              Proceed to Checkout
            </Button>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center text-gray-600">
          <ShoppingCartOutlined
            style={{ fontSize: "48px", marginBottom: "16px" }}
          />
          <Text>Your cart is empty!</Text>
          <Button
            type="primary"
            size="large"
            className="bg-orange-500 text-white hover:bg-orange-600 mt-6"
            onClick={() => navigate("/")}
          >
            Continue Shopping
          </Button>
        </div>
      )}
    </div>
  );
};

export default CartPage;
