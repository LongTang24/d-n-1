import React, { useState } from "react";
import { Button, Form, Input, Typography, message, Space, Card } from "antd";
import { useNavigate } from "react-router-dom";
import { register } from "../api/services/authService";

const { Title } = Typography;

const Register = () => {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const onFinish = async (values) => {
    setLoading(true);
    try {
      const { email, password } = values;
      const response = await register(email, password);
      message.success(response.message || "Registration successful!");
      navigate("/login");
    } catch (error) {
      message.error(error.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-orange-400 via-red-500 to-pink-500">
      <Card className="w-full max-w-md p-6 shadow-2xl rounded-xl bg-white/90 backdrop-blur-sm transform transition-all hover:scale-105">
        <Space direction="vertical" className="w-full" align="center">
          <Title level={2} className="text-orange-600 font-bold tracking-wide">
            Create Account
          </Title>
          <Form
            name="registerForm"
            layout="vertical"
            onFinish={onFinish}
            className="w-full"
          >
            <Form.Item
              name="email"
              label={<span className="text-gray-700 font-semibold">Email</span>}
              rules={[
                { required: true, message: "Please enter your email" },
                { type: "email", message: "Please enter a valid email" },
              ]}
            >
              <Input
                className="rounded-lg border-gray-300 focus:ring-2 focus:ring-orange-500 transition-all"
                placeholder="Enter your email"
              />
            </Form.Item>
            <Form.Item
              name="password"
              label={<span className="text-gray-700 font-semibold">Password</span>}
              rules={[
                { required: true, message: "Please enter your password" },
                { min: 6, message: "Password must be at least 6 characters" },
              ]}
            >
              <Input.Password
                className="rounded-lg border-gray-300 focus:ring-2 focus:ring-orange-500 transition-all"
                placeholder="Enter your password"
              />
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                block
                loading={loading}
                className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold rounded-lg py-2 transition-all duration-300"
              >
                Register
              </Button>
            </Form.Item>
            <div className="text-center text-gray-600">
              Already have an account?{" "}
              <a
                onClick={() => navigate("/login")}
                className="text-orange-500 hover:text-orange-700 font-semibold transition-colors"
              >
                Login here
              </a>
            </div>
          </Form>
        </Space>
      </Card>
    </div>
  );
};

export default Register;