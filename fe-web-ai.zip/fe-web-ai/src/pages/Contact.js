import React from "react";
import { Typography, Card, Form, Input, Button } from "antd";
import { MailOutlined, PhoneOutlined } from "@ant-design/icons";

const { Title, Paragraph } = Typography;

const Contact = () => {
  const [form] = Form.useForm();

  const handleSubmit = (values) => {
    console.log("Submitted Values:", values);
    form.resetFields();
    alert("Thank you for reaching out! We’ll get back to you soon.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 py-12 flex items-center justify-center">
      <div className="container mx-auto px-6">
        <Card
          className="w-full sm:w-4/5 md:w-3/5 lg:w-2/5 mx-auto bg-white/90 backdrop-blur-sm"
          style={{
            boxShadow: "0 8px 24px rgba(0, 0, 0, 0.2)",
            borderRadius: "16px",
            padding: "32px",
          }}
        >
          {/* Header */}
          <Title level={2} className="text-center text-orange-600 font-bold tracking-wide">
            Contact Clothing Store
          </Title>
          <Paragraph className="text-center text-gray-700 mb-8">
            Have questions or feedback? Drop us a message, and we’ll respond faster than you can say "style"!
          </Paragraph>

          {/* Form */}
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            className="space-y-6"
          >
            <Form.Item
              name="name"
              label={<span className="text-orange-600 font-semibold">Your Name</span>}
              rules={[{ required: true, message: "Please enter your name!" }]}
            >
              <Input
                placeholder="Enter your full name"
                className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </Form.Item>

            <Form.Item
              name="email"
              label={<span className="text-orange-600 font-semibold">Your Email</span>}
              rules={[
                { required: true, message: "Please enter your email!" },
                { type: "email", message: "Please enter a valid email!" },
              ]}
            >
              <Input
                placeholder="Enter your email address"
                className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </Form.Item>

            <Form.Item
              name="message"
              label={<span className="text-orange-600 font-semibold">Your Message</span>}
              rules={[{ required: true, message: "Please enter your message!" }]}
            >
              <Input.TextArea
                rows={4}
                placeholder="Tell us what’s on your mind"
                className="rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
              />
            </Form.Item>

            <div className="flex justify-center">
              <Button
                type="primary"
                htmlType="submit"
                className="bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 px-8 py-2 rounded-lg font-semibold shadow-lg transition-all duration-300"
              >
                Send Message
              </Button>
            </div>
          </Form>

          {/* Contact Info */}
          <div className="text-center mt-10 text-gray-700">
            <p className="text-orange-600 font-semibold">Or reach us directly:</p>
            <div className="mt-4 space-y-2">
              <p className="flex items-center justify-center gap-2">
                <MailOutlined className="text-orange-600" />
                <span>
                  <strong>Email:</strong> support@ClothingStore.com
                </span>
              </p>
              <p className="flex items-center justify-center gap-2">
                <PhoneOutlined className="text-orange-600" />
                <span>
                  <strong>Phone:</strong> +84 875 328 4234
                </span>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Contact;