import React, { useState, useEffect, useRef } from "react";
import { Input, Button, Avatar, message, Spin } from "antd";
import { SendOutlined, UserOutlined } from "@ant-design/icons";
import Lottie from "lottie-react";
import typingAnimation from "../components/animations/typing.json";
import chatbotAnimation from "../components/animations/chatbot.json";
import { sendPromptToGemini } from "../api/services/chatService";
import { getProducts } from "../api/services/productService";

const AiPage = () => {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  // Fetch products when the component mounts
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const productsData = await getProducts();
        setProducts(productsData);
      } catch (error) {
        console.error("Failed to fetch products:", error);
        message.error("Failed to load products.");
      }
    };
    fetchProducts();
  }, []);

  // Scroll to the bottom of the chat when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sanitizeJSONResponse = (response) => {
    return response.replace(/```json|```/g, "").trim();
  };

  const handleSendPrompt = async () => {
    if (!prompt.trim()) {
      message.warning("Please enter a prompt.");
      return;
    }

    setMessages([...messages, { text: prompt, sender: "user", timestamp: new Date() }]);
    setLoading(true);
    setPrompt("");

    try {
      const aiPrompt = `
You are an AI assistant for a clothing store. You are given the following list of products:
${JSON.stringify(products)}

If the user's query is about product recommendations (e.g., cheapest product, most expensive product, highlighted products within a specific price range), respond with a JSON object in the format:

{
  "recommendations": [
    {
      "id": "product_id",
      "name": "product_name",
      "price": "product_price",
      "imageUrl": "product_image_url",
      "description": "product_description"
    }
  ]
}

If the query is unrelated to products, respond with a normal text message.

User Query: "${prompt}"
`;

      const apiResponse = await sendPromptToGemini(aiPrompt);
      let recommendations = [];
      let aiTextResponse = "";

      try {
        const sanitizedResponse = sanitizeJSONResponse(apiResponse);
        const parsedResponse = JSON.parse(sanitizedResponse);

        if (parsedResponse.recommendations) {
          recommendations = parsedResponse.recommendations;
        } else {
          aiTextResponse = apiResponse.trim();
        }
      } catch (err) {
        aiTextResponse = apiResponse.trim();
      }

      setMessages((prevMessages) => [
        ...prevMessages,
        {
          text: recommendations.length ? "Here are some stylish picks for you:" : aiTextResponse,
          products: recommendations,
          sender: "ai",
          timestamp: new Date(),
        },
      ]);
    } catch (error) {
      console.error("Error communicating with AI:", error);
      message.error("Failed to get a response.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 flex flex-col items-center py-12">
      {/* Header Section */}
      <div className="w-full max-w-4xl text-center mb-8">
        <h1 className="text-5xl font-bold text-white tracking-wide drop-shadow-lg">
          StyleBot
        </h1>
        <p className="text-lg text-white mt-2 drop-shadow-md">
          Your AI-Powered Fashion Companion
        </p>
      </div>

      {/* Chat Section */}
      <div className="w-full max-w-4xl bg-white/90 backdrop-blur-sm shadow-xl rounded-xl overflow-hidden flex flex-col h-[70vh]">
        {/* Messages */}
        <div className="flex-1 p-6 overflow-y-auto">
          {messages.length === 0 && !loading && (
            <div className="h-full flex flex-col justify-center items-center text-orange-600">
              <Lottie animationData={chatbotAnimation} style={{ width: 120, height: 120 }} />
              <p className="mt-4 text-lg font-semibold">
                Ask StyleBot anything about fashion or our collection!
              </p>
            </div>
          )}
          {messages.map((message, index) => (
            <div key={index} className="mb-6">
              {/* Text Message */}
              <div
                className={`flex ${
                  message.sender === "user" ? "justify-end" : "justify-start"
                } items-start gap-3`}
              >
                {message.sender === "ai" && (
                  <div className="w-10 h-10 flex-shrink-0">
                    <Lottie animationData={chatbotAnimation} style={{ width: "100%", height: "100%" }} />
                  </div>
                )}
                <div
                  className={`max-w-[70%] p-4 rounded-xl shadow-md ${
                    message.sender === "user"
                      ? "bg-gradient-to-r from-orange-500 to-red-600 text-white"
                      : "bg-white border border-orange-300 text-orange-600"
                  }`}
                >
                  <p>{message.text}</p>
                  <span className="text-xs mt-2 block opacity-75">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
                {message.sender === "user" && (
                  <Avatar icon={<UserOutlined />} size="large" className="flex-shrink-0" />
                )}
              </div>

              {/* Product Recommendations */}
              {message.products?.length > 0 && (
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {message.products.map((product) => (
                    <div
                      key={product.id}
                      className="bg-white rounded-lg shadow-md overflow-hidden transform transition-all hover:scale-105"
                    >
                      <img
                        alt={product.name}
                        src={product.imageUrl || "https://via.placeholder.com/300"}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-4">
                        <p className="text-orange-600 font-semibold truncate">{product.name}</p>
                        <p className="text-gray-600 text-sm line-clamp-2">{product.description}</p>
                        <p className="text-orange-600 font-bold mt-2">
                          {Number(product.price).toLocaleString()} VND
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
          {loading && (
            <div className="flex justify-start items-center gap-3">
              <div className="w-10 h-10">
                <Lottie animationData={chatbotAnimation} style={{ width: "100%", height: "100%" }} />
              </div>
              <div className="flex items-center bg-white p-4 rounded-xl shadow-md">
                <Lottie animationData={typingAnimation} style={{ width: 40, height: 40 }} />
                <span className="text-orange-600 ml-2">StyleBot is thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Section */}
        <div className="bg-white/95 border-t border-orange-200 p-4">
          <div className="flex items-center gap-4">
            <Input.TextArea
              rows={2}
              placeholder="Ask StyleBot anything!"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onPressEnter={handleSendPrompt}
              className="flex-1 resize-none rounded-lg border-orange-300 focus:ring-2 focus:ring-orange-500 transition-all"
            />
            <Button
              loading={loading}
              onClick={handleSendPrompt}
              className="bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg px-6 py-2 font-semibold transition-all duration-300 flex items-center gap-2"
            >
              <SendOutlined />
              Send
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiPage;