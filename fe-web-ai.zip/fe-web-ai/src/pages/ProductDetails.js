import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProducts } from "../api/services/productService";
import { addToCart, getCart } from "../api/services/cartService";
import { Typography, Button, Badge, message, Rate, Spin } from "antd";
import {
  ShoppingCartOutlined,
  SafetyOutlined,
  StarOutlined,
} from "@ant-design/icons";
import { useCart } from "../context/CartContext";

const { Title, Text, Paragraph } = Typography;

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const { updateCartCount } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const products = await getProducts();
        const selectedProduct = products.find((p) => p.id === id);
        setProduct(selectedProduct || null);
      } catch (error) {
        console.error("Error fetching product details:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id]);

  const handleAddToCart = async () => {
    try {
      if (product.stock <= 0) {
        message.error("This product is out of stock.");
        return;
      }
      await addToCart(product.id, 1);
      const cartData = await getCart();
      const totalItems = cartData.reduce((sum, item) => sum + item.quantity, 0);
      updateCartCount(totalItems);
      message.success("Product added to cart successfully!");
    } catch (error) {
      console.error("Error adding to cart:", error);
      message.error("Failed to add product to cart.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 flex justify-center items-center">
        <Spin size="large" className="text-white" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 flex justify-center items-center">
        <Text className="text-white text-lg drop-shadow-md">
          Product not found.
        </Text>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 py-12">
      <div className="container mx-auto px-6">
        {/* Product Main Section */}
        <section className="bg-white/90 backdrop-blur-sm rounded-xl shadow-xl p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="relative rounded-lg overflow-hidden transform transition-all hover:scale-105">
            <img
              src={product.imageUrl || "https://via.placeholder.com/600"}
              alt={product.name}
              className="w-full h-[500px] object-cover"
            />
            <Badge
              count={product.stock > 0 ? "In Stock" : "Out of Stock"}
              style={{
                backgroundColor: product.stock > 0 ? "#f97316" : "#e11d48",
                color: "white",
                position: "absolute",
                top: 10,
                left: 10,
                padding: "4px 8px",
                borderRadius: "4px",
              }}
            />
          </div>

          {/* Product Details */}
          <div className="flex flex-col space-y-6">
            <div>
              <Title level={2} className="text-orange-600 font-bold tracking-wide">
                {product.name}
              </Title>
              <div className="flex items-center space-x-2">
                <Rate allowHalf defaultValue={4.5} disabled className="text-orange-500" />
                <Text className="text-gray-600">(50 reviews)</Text>
              </div>
            </div>

            <Paragraph className="text-gray-700 text-base line-clamp-4">
              {product.description}
            </Paragraph>

            <div className="flex items-center space-x-4">
              <Title level={3} className="text-orange-600 font-semibold">
                {product.price.toLocaleString()} VND
              </Title>
              <Text className="text-gray-600">Stock: {product.stock}</Text>
            </div>

            <div className="flex flex-col space-y-4">
              <Button
                size="large"
                icon={<ShoppingCartOutlined />}
                onClick={handleAddToCart}
                className="bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg font-semibold transition-all duration-300"
              >
                Add to Cart
              </Button>
              <Button
                size="large"
                onClick={() => navigate("/search")}
                className="text-orange-600 border-orange-600 hover:bg-orange-100 rounded-lg transition-all"
              >
                Back to Search
              </Button>
            </div>

            {/* Product Highlights */}
            <div className="bg-gray-100/50 p-4 rounded-lg">
              <Title level={5} className="text-orange-600 font-semibold">
                Product Highlights
              </Title>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                <li>Secure Payment Options</li>
                <li>High-Quality Materials</li>
                <li>Fast Shipping Available</li>
                <li>30-Day Return Policy</li>
              </ul>
            </div>

            {/* Icons */}
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <SafetyOutlined className="text-orange-600 text-xl" />
                <Text className="text-gray-700">Secure Payment</Text>
              </div>
              <div className="flex items-center space-x-2">
                <StarOutlined className="text-orange-600 text-xl" />
                <Text className="text-gray-700">Top-rated Product</Text>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default ProductDetails;