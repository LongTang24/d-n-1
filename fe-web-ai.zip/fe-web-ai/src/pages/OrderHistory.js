import React, { useEffect, useState } from "react";
import { Table, Spin, message, Tag, Typography, Button } from "antd";
import { getOrderHistory } from "../api/services/orderService";
import { useNavigate } from "react-router-dom";

const { Title } = Typography;

const OrderHistoryPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrders = async () => {
      setLoading(true);
      try {
        const orderData = await getOrderHistory();
        setOrders(orderData);
      } catch (error) {
        message.error("Failed to fetch order history.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  const columns = [
    {
      title: "Order ID",
      dataIndex: "id",
      key: "id",
      render: (id) => (
        <Button
          type="link"
          onClick={() => navigate(`/order/${id}`)}
          className="text-orange-500 font-semibold hover:underline"
        >
          {id}
        </Button>
      ),
    },
    {
      title: "Total",
      dataIndex: "total",
      key: "total",
      render: (total) => (
        <span className="font-bold text-orange-500">{`${total.toLocaleString()} VND`}</span>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        let color = "blue";
        if (status === "Completed") color = "green";
        if (status === "Pending") color = "orange";
        if (status === "Cancelled") color = "red";
        return (
          <Tag color={color} className="font-medium">
            {status}
          </Tag>
        );
      },
    },
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (date) => (
        <span className="text-gray-600">{new Date(date).toLocaleString()}</span>
      ),
    },
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gradient-to-br from-orange-100 to-white">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-white py-10">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <Title level={2} className="text-orange-500 font-extrabold">
            Order History
          </Title>
          <p className="text-gray-600">
            Review all your past orders and their statuses.
          </p>
        </div>

        {/* Order Table */}
        <div className="bg-white shadow-lg rounded-lg p-6">
          <Table
            dataSource={orders}
            columns={columns}
            rowKey="id"
            pagination={{
              pageSize: 5,
              showSizeChanger: false,
            }}
            className="rounded-lg"
          />
        </div>
      </div>
    </div>
  );
};

export default OrderHistoryPage;
