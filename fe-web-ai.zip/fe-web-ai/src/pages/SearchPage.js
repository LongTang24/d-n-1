import React, { useEffect, useState } from "react";
import {
  Input,
  Slider,
  Button,
  Badge,
  Typography,
  Select,
  message,
} from "antd";
import {
  ShoppingCartOutlined,
  InfoCircleOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import { getProducts } from "../api/services/productService";
import { getCategories } from "../api/services/categoryService";
import { addToCart, getCart } from "../api/services/cartService";
import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";

const { Title, Paragraph } = Typography;
const { Option } = Select;

const SearchPage = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [priceRange, setPriceRange] = useState([0, 1000000]);
  const [stockStatus, setStockStatus] = useState(null);
  const { updateCartCount } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productsData = await getProducts();
        const categoriesData = await getCategories();
        setProducts(productsData);
        setFilteredProducts(productsData);
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleSearch = () => {
    let filtered = products;

    if (searchTerm) {
      filtered = filtered.filter((product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory) {
      filtered = filtered.filter((product) => product.categoryId === selectedCategory);
    }

    filtered = filtered.filter(
      (product) => product.price >= priceRange[0] && product.price <= priceRange[1]
    );

    if (stockStatus !== null) {
      filtered = filtered.filter((product) => (stockStatus ? product.stock > 0 : product.stock === 0));
    }

    setFilteredProducts(filtered);
  };

  const handleAddToCart = async (product) => {
    try {
      if (product.stock <= 0) {
        message.error("This product is out of stock.");
        return;
      }
      await addToCart(product.id, 1);
      const cartData = await getCart();
      const totalItems = cartData.reduce((sum, item) => sum + item.quantity, 0);
      updateCartCount(totalItems);
      message.success(`${product.name} added to cart successfully!`);
    } catch (error) {
      console.error("Error adding to cart:", error);
      message.error("Failed to add product to cart.");
    }
  };

  const handleViewDetails = (productId) => {
    navigate(`/product/${productId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 py-12">
      <div className="container mx-auto px-6">
        {/* Header */}
        <section className="text-center mb-12">
          <Title level={1} className="text-white font-bold tracking-wide drop-shadow-lg">
            Find Your Style
          </Title>
          <Paragraph className="text-lg text-white max-w-2xl mx-auto drop-shadow-md">
            Search and filter our clothing collection to find exactly what you’re looking for.
          </Paragraph>
        </section>

        {/* Filters */}
        <section className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-xl mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Search Input */}
            <Input
              placeholder="Search products..."
              prefix={<SearchOutlined className="text-orange-600" />}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="rounded-lg border-orange-500 focus:ring-2 focus:ring-orange-500 transition-all"
            />

            {/* Category Filter */}
            <Select
              placeholder="Select Category"
              allowClear
              onChange={setSelectedCategory}
              className="w-full"
            >
              {categories.map((category) => (
                <Option key={category.id} value={category.id}>
                  {category.name}
                </Option>
              ))}
            </Select>

            {/* Stock Status Filter */}
            <Select
              placeholder="Stock Status"
              allowClear
              onChange={setStockStatus}
              className="w-full"
            >
              <Option value={true}>In Stock</Option>
              <Option value={false}>Out of Stock</Option>
            </Select>

            {/* Apply Filters Button */}
            <Button
              onClick={handleSearch}
              className="bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg font-semibold transition-all duration-300"
            >
              Apply Filters
            </Button>
          </div>

          {/* Price Range Slider */}
          <div className="mt-6">
            <Title level={5} className="text-orange-600 font-semibold">
              Price Range
            </Title>
            <div className="flex items-center">
              <Slider
                range
                max={1000000}
                step={50000}
                value={priceRange}
                onChange={setPriceRange}
                trackStyle={{ backgroundColor: "#f97316" }}
                handleStyle={{ borderColor: "#f97316" }}
                className="flex-1"
              />
              <span className="ml-4 text-orange-600 font-semibold">
                {priceRange[0].toLocaleString()} - {priceRange[1].toLocaleString()} VND
              </span>
            </div>
          </div>
        </section>

        {/* Product List */}
        <section>
          {filteredProducts.length > 0 ? (
            <div className="space-y-8">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex flex-col md:flex-row items-center bg-white/90 backdrop-blur-sm rounded-xl shadow-xl overflow-hidden transition-all hover:shadow-2xl"
                >
                  <img
                    alt={product.name}
                    src={product.imageUrl || "https://via.placeholder.com/300"}
                    className="w-full md:w-1/3 h-80 object-cover transition-transform duration-300 hover:scale-105"
                  />
                  <div className="p-6 flex-1">
                    <Title level={4} className="text-orange-600 font-semibold">
                      {product.name}
                    </Title>
                    <Paragraph className="text-gray-600 text-sm line-clamp-2">
                      {product.description}
                    </Paragraph>
                    <div className="flex justify-between items-center mt-4">
                      <span className="text-lg font-bold text-orange-600">
                        {product.price.toLocaleString()} VND
                      </span>
                      <Badge
                        count={product.stock > 0 ? "In Stock" : "Out of Stock"}
                        style={{ backgroundColor: product.stock > 0 ? "#f97316" : "#e11d48", color: "white" }}
                      />
                    </div>
                    <div className="flex gap-4 mt-4">
                      <Button
                        icon={<InfoCircleOutlined />}
                        onClick={() => handleViewDetails(product.id)}
                        className="w-full text-orange-600 border-orange-600 hover:bg-orange-100 rounded-lg transition-all"
                      >
                        View Details
                      </Button>
                      <Button
                        icon={<ShoppingCartOutlined />}
                        onClick={() => handleAddToCart(product)}
                        className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white hover:from-orange-600 hover:to-red-700 rounded-lg transition-all"
                      >
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-white text-lg drop-shadow-md">
              No products found matching your criteria.
            </p>
          )}
        </section>
      </div>
    </div>
  );
};

export default SearchPage;