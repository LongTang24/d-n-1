import React, { useState, useContext } from "react";
import { Button, Form, Input, Typography, message, Space, Card } from "antd";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { login as loginApi } from "../api/services/authService";

const { Title } = Typography;

const Login = () => {
  const [loading, setLoading] = useState(false);
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const onFinish = async (values) => {
    setLoading(true);
    try {
      const { email, password } = values;
      const response = await loginApi(email, password);
      const token = response.data.token;
      login(token);
      message.success("Login successful!");
      const role = localStorage.getItem("userRole");
      if (role === "admin") {
        navigate("/admin");
      } else {
        navigate("/");
      }
    } catch (error) {
      if (error.response?.status === 404) {
        message.info("Account does not exist. Redirecting to register page...");
        navigate("/register");
      } else {
        message.error(error.response?.data?.message || "Invalid credentials");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-orange-400 via-red-500 to-pink-500">
      <Card className="w-full max-w-md p-6 shadow-2xl rounded-xl bg-white/90 backdrop-blur-sm transform transition-all hover:scale-105">
        <Space direction="vertical" className="w-full" align="center">
          <Title level={2} className="text-orange-600 font-bold tracking-wide">
            Welcome Back
          </Title>
          <Form
            name="loginForm"
            layout="vertical"
            onFinish={onFinish}
            className="w-full"
          >
            <Form.Item
              name="email"
              label={<span className="text-gray-700 font-semibold">Email</span>}
              rules={[
                { required: true, message: "Please enter your email" },
                { type: "email", message: "Please enter a valid email" },
              ]}
            >
              <Input
                className="rounded-lg border-gray-300 focus:ring-2 focus:ring-orange-500 transition-all"
                placeholder="Enter your email"
              />
            </Form.Item>
            <Form.Item
              name="password"
              label={<span className="text-gray-700 font-semibold">Password</span>}
              rules={[
                { required: true, message: "Please enter your password" },
              ]}
            >
              <Input.Password
                className="rounded-lg border-gray-300 focus:ring-2 focus:ring-orange-500 transition-all"
                placeholder="Enter your password"
              />
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                block
                loading={loading}
                className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-semibold rounded-lg py-2 transition-all duration-300"
              >
                Login
              </Button>
            </Form.Item>
            <div className="text-center text-gray-600">
              Don’t have an account?{" "}
              <a
                onClick={() => navigate("/register")}
                className="text-orange-500 hover:text-orange-700 font-semibold transition-colors"
              >
                Register here
              </a>
            </div>
          </Form>
        </Space>
      </Card>
    </div>
  );
};

export default Login;