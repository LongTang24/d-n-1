import React, { useEffect, useState } from "react";
import { Form, Input, Button, message, Spin, Avatar } from "antd";
import { getUserProfile, updateUserProfile } from "../api/services/userService";
import ImageUpload from "../components/image/ImageUpload";

const ProfilePage = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [avatarUrl, setAvatarUrl] = useState("");

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      try {
        const profileData = await getUserProfile();
        setProfile(profileData);
        setAvatarUrl(profileData.avatar || "");
        form.setFieldsValue({
          firstName: profileData.firstName,
          lastName: profileData.lastName,
          email: profileData.email,
          phone: profileData.phone,
          address: profileData.address,
        });
      } catch (error) {
        message.error("Failed to fetch profile data.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [form]);

  const handleImageUpload = (url) => {
    setAvatarUrl(url);
  };

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const updatedProfile = { ...values, avatar: avatarUrl };
      await updateUserProfile(updatedProfile);
      message.success("Profile updated successfully.");
    } catch (error) {
      message.error("Failed to update profile.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gradient-to-br from-orange-100 to-white">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-10 bg-gradient-to-br from-orange-50 to-white shadow-lg rounded-lg">
      {/* Title */}
      <h1 className="text-3xl font-extrabold text-orange-500 mb-6 text-center">
        My Profile
      </h1>

      {/* Avatar and Upload Section */}
      <div className="flex flex-col items-center space-y-4">
        <Avatar
          size={120}
          src={avatarUrl || "https://via.placeholder.com/120"}
          className="shadow-lg border-4 border-orange-500"
        />
        <ImageUpload onImageUpload={handleImageUpload} />
      </div>

      {/* Form */}
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        className="max-w-lg mx-auto mt-8 space-y-4"
      >
        <Form.Item
          name="firstName"
          label={<span className="text-orange-500">First Name</span>}
          rules={[{ required: true, message: "Please input your first name!" }]}
        >
          <Input className="rounded-lg border-orange-300" />
        </Form.Item>
        <Form.Item
          name="lastName"
          label={<span className="text-orange-500">Last Name</span>}
          rules={[{ required: true, message: "Please input your last name!" }]}
        >
          <Input className="rounded-lg border-orange-300" />
        </Form.Item>
        <Form.Item
          name="email"
          label={<span className="text-orange-500">Email</span>}
          rules={[{ type: "email", message: "Please enter a valid email!" }]}
        >
          <Input
            disabled
            className="rounded-lg border-orange-300 bg-gray-100"
          />
        </Form.Item>
        <Form.Item
          name="phone"
          label={<span className="text-orange-500">Phone Number</span>}
          rules={[
            { required: true, message: "Please input your phone number!" },
          ]}
        >
          <Input className="rounded-lg border-orange-300" />
        </Form.Item>
        <Form.Item
          name="address"
          label={<span className="text-orange-500">Address</span>}
          rules={[{ required: true, message: "Please input your address!" }]}
        >
          <Input.TextArea rows={3} className="rounded-lg border-orange-300" />
        </Form.Item>
        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            block
            loading={loading}
            className="bg-orange-500 text-white hover:bg-orange-600 rounded-lg shadow-lg"
          >
            Update Profile
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default ProfilePage;
